package es.unican.is2.Practica4;

public enum Cobertura {

	TERCEROS,TODORIESGO,TERCEROSLUNAS;
}
